
'use client';

import Link from 'next/link';

export default function ContactCTA() {
  return (
    <section className="py-20 bg-blue-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Ready to Start Your Project?
        </h2>
        <p className="text-xl mb-8 max-w-3xl mx-auto">
          Get in touch with our team of professional civil engineers for a consultation 
          and free project quote.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            href="/contact" 
            className="bg-white text-blue-600 px-8 py-4 rounded-md hover:bg-gray-100 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
          >
            Get Free Quote
          </Link>
          <a 
            href="tel:9889307968" 
            className="border-2 border-white text-white px-8 py-4 rounded-md hover:bg-white hover:text-blue-600 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
          >
            Call Now: 9889307968
          </a>
        </div>
      </div>
    </section>
  );
}
