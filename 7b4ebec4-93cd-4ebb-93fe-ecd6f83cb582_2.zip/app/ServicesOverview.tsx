
'use client';

import Link from 'next/link';

export default function ServicesOverview() {
  const services = [
    {
      icon: 'ri-roadster-line',
      title: 'Highway Construction',
      description: 'Professional highway and road construction services with experience in major projects like Purvanchal Expressway.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20highway%20construction%20with%20heavy%20machinery%2C%20asphalt%20laying%20equipment%2C%20road%20marking%2C%20professional%20construction%20site%20with%20safety%20protocols%2C%20blue%20sky%20background%2C%20clean%20industrial%20scene&width=400&height=300&seq=highway-service&orientation=landscape'
    },
    {
      icon: 'ri-home-line',
      title: 'Residential Projects',
      description: 'Quality residential construction from individual homes to large housing complexes with modern amenities.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20residential%20building%20construction%20site%20with%20apartment%20complex%20under%20development%2C%20construction%20cranes%2C%20workers%20in%20safety%20gear%2C%20contemporary%20architecture%2C%20bright%20daylight&width=400&height=300&seq=residential-service&orientation=landscape'
    },
    {
      icon: 'ri-building-line',
      title: 'Commercial Construction',
      description: 'Commercial building construction services including offices, retail spaces, and industrial facilities.',
      image: 'https://readdy.ai/api/search-image?query=Commercial%20building%20construction%20site%20with%20office%20complex%20under%20construction%2C%20steel%20framework%2C%20glass%20facade%20installation%2C%20modern%20architecture%2C%20professional%20construction%20environment&width=400&height=300&seq=commercial-service&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Construction Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive construction solutions across multiple sectors with 
            expertise in highways, residential, and commercial projects.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(${service.image})` }}></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <i className={`${service.icon} text-2xl text-blue-600 w-8 h-8 flex items-center justify-center mr-3`}></i>
                  <h3 className="text-xl font-semibold text-gray-900">{service.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <Link 
                  href="/services" 
                  className="text-blue-600 hover:text-blue-800 font-medium cursor-pointer"
                >
                  Learn More →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
