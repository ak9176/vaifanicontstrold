
'use client';

export default function ServicesHero() {
  return (
    <section 
      className="relative h-96 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Construction%20services%20overview%20with%20multiple%20construction%20sites%2C%20highways%2C%20residential%20buildings%2C%20commercial%20projects%2C%20professional%20construction%20equipment%2C%20comprehensive%20construction%20services&width=1920&height=600&seq=services-hero&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-center w-full">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our Construction Services
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Comprehensive construction solutions for highways, residential, commercial, and consultancy services
          </p>
        </div>
      </div>
    </section>
  );
}
