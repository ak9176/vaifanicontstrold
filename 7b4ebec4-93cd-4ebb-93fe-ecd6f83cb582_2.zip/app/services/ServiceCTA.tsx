
'use client';

import Link from 'next/link';

export default function ServiceCTA() {
  return (
    <section className="py-20 bg-blue-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Need Professional Construction Services?
        </h2>
        <p className="text-xl mb-8 max-w-3xl mx-auto">
          Contact our team of qualified engineers for a detailed consultation 
          and customized solution for your construction needs.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            href="/contact" 
            className="bg-white text-blue-600 px-8 py-4 rounded-md hover:bg-gray-100 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
          >
            Request Quote
          </Link>
          <Link 
            href="/projects" 
            className="border-2 border-white text-white px-8 py-4 rounded-md hover:bg-white hover:text-blue-600 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer"
          >
            View Our Work
          </Link>
        </div>
      </div>
    </section>
  );
}
