
'use client';

export default function ServicesGrid() {
  const services = [
    {
      icon: 'ri-roadster-line',
      title: 'Road Construction',
      description: 'Professional highway and road construction services with expertise in major infrastructure projects.',
      features: [
        'Highway construction and maintenance',
        'Expressway structural work',
        'Bridge and flyover construction',
        'Road widening and improvement',
        'Traffic management systems'
      ],
      image: 'https://readdy.ai/api/search-image?query=Highway%20construction%20with%20asphalt%20laying%20machine%2C%20road%20construction%20equipment%2C%20workers%20in%20safety%20gear%2C%20modern%20highway%20development%2C%20professional%20road%20building&width=500&height=300&seq=road-construction&orientation=landscape'
    },
    {
      icon: 'ri-home-line',
      title: 'Real Estate',
      description: 'Quality residential construction from individual homes to large housing complexes and townships.',
      features: [
        'Residential apartments and complexes',
        'Independent house construction',
        'Township development',
        'Interior design and finishing',
        'Landscaping and amenities'
      ],
      image: 'https://readdy.ai/api/search-image?query=Residential%20construction%20with%20apartment%20buildings%20under%20development%2C%20modern%20housing%20complex%2C%20construction%20cranes%2C%20quality%20residential%20architecture&width=500&height=300&seq=real-estate&orientation=landscape'
    },
    {
      icon: 'ri-building-line',
      title: 'Public Facility Construction',
      description: 'Construction of public infrastructure including government buildings, schools, and community facilities.',
      features: [
        'Government office buildings',
        'Educational institutions',
        'Healthcare facilities',
        'Community centers',
        'Public utility buildings'
      ],
      image: 'https://readdy.ai/api/search-image?query=Public%20building%20construction%20with%20government%20facility%20under%20development%2C%20modern%20institutional%20architecture%2C%20construction%20site%20with%20safety%20protocols&width=500&height=300&seq=public-facility&orientation=landscape'
    },
    {
      icon: 'ri-file-text-line',
      title: 'Consultancy Services',
      description: 'Professional engineering consultancy for project planning, design, and construction management.',
      features: [
        'Project feasibility studies',
        'Architectural and structural design',
        'Construction planning and management',
        'Quality control and supervision',
        'Cost estimation and budgeting'
      ],
      image: 'https://readdy.ai/api/search-image?query=Engineering%20consultancy%20with%20architects%20reviewing%20blueprints%2C%20professional%20engineers%20at%20work%2C%20construction%20planning%2C%20technical%20drawings%20and%20documents&width=500&height=300&seq=consultancy&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Comprehensive Construction Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We offer a complete range of construction services backed by professional expertise and quality assurance
          </p>
        </div>
        
        <div className="space-y-16">
          {services.map((service, index) => (
            <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
              index % 2 === 1 ? 'lg:flex-row-reverse' : ''
            }`}>
              <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                <div className="flex items-center mb-6">
                  <i className={`${service.icon} text-3xl text-blue-600 w-10 h-10 flex items-center justify-center mr-4`}></i>
                  <h3 className="text-2xl font-bold text-gray-900">{service.title}</h3>
                </div>
                <p className="text-lg text-gray-600 mb-6">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-700">
                      <i className="ri-check-line text-green-600 w-5 h-5 flex items-center justify-center mr-3"></i>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-80 object-cover object-top"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
