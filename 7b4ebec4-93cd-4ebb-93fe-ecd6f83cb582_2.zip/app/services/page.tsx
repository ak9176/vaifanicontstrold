
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ServicesHero from './ServicesHero';
import ServicesGrid from './ServicesGrid';
import ServiceProcess from './ServiceProcess';
import ServiceCTA from './ServiceCTA';

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ServicesHero />
        <ServicesGrid />
        <ServiceProcess />
        <ServiceCTA />
      </main>
      <Footer />
    </div>
  );
}
