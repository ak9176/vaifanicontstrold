
'use client';

export default function ServiceProcess() {
  const steps = [
    {
      number: '01',
      title: 'Initial Consultation',
      description: 'We meet with clients to understand project requirements, scope, and objectives.',
      icon: 'ri-question-answer-line'
    },
    {
      number: '02',
      title: 'Project Planning',
      description: 'Detailed project planning including design, timeline, and resource allocation.',
      icon: 'ri-file-list-line'
    },
    {
      number: '03',
      title: 'Design & Approval',
      description: 'Professional design creation and obtaining necessary approvals and permits.',
      icon: 'ri-edit-box-line'
    },
    {
      number: '04',
      title: 'Construction Phase',
      description: 'Skilled execution with quality control, safety measures, and regular monitoring.',
      icon: 'ri-hammer-line'
    },
    {
      number: '05',
      title: 'Quality Assurance',
      description: 'Rigorous quality checks and testing to ensure project meets specifications.',
      icon: 'ri-shield-check-line'
    },
    {
      number: '06',
      title: 'Project Handover',
      description: 'Final inspection, documentation, and project handover to the client.',
      icon: 'ri-trophy-line'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Construction Process
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We follow a systematic approach to ensure quality delivery and client satisfaction
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-blue-600 font-bold">{step.number}</span>
                </div>
                <i className={`${step.icon} text-2xl text-blue-600 w-8 h-8 flex items-center justify-center`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
