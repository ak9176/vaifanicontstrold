
'use client';

import Link from 'next/link';

export default function ProjectHighlights() {
  const projects = [
    {
      title: 'Purvanchal Expressway - Structural Work',
      category: 'Highway Infrastructure',
      description: 'Major structural construction work on the prestigious Purvanchal Expressway project.',
      image: 'https://readdy.ai/api/search-image?query=Expressway%20construction%20with%20concrete%20structures%2C%20highway%20bridges%20under%20construction%2C%20heavy%20machinery%2C%20professional%20engineering%20work%2C%20modern%20infrastructure%20development%2C%20blue%20sky%20background&width=600&height=400&seq=purvanchal-project&orientation=landscape',
      status: 'Completed'
    },
    {
      title: 'Commercial Complex - Dehradun',
      category: 'Commercial Development',
      description: 'Multi-story commercial building with modern amenities and sustainable design.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20commercial%20building%20construction%20in%20Dehradun%20city%2C%20multi-story%20office%20complex%2C%20glass%20facade%2C%20steel%20framework%2C%20urban%20development%2C%20professional%20construction%20site&width=600&height=400&seq=dehradun-commercial&orientation=landscape',
      status: 'In Progress'
    },
    {
      title: 'Residential Township - Lucknow',
      category: 'Residential Development',
      description: 'Integrated residential township with modern infrastructure and facilities.',
      image: 'https://readdy.ai/api/search-image?query=Residential%20township%20construction%20with%20multiple%20apartment%20buildings%2C%20modern%20housing%20complex%2C%20landscaped%20environment%2C%20construction%20cranes%2C%20quality%20residential%20development&width=600&height=400&seq=lucknow-residential&orientation=landscape',
      status: 'Completed'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Featured Projects
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Showcasing our expertise through successfully completed and ongoing construction projects
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="h-64 bg-cover bg-center" style={{ backgroundImage: `url(${project.image})` }}></div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-600">{project.category}</span>
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    project.status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {project.status}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{project.title}</h3>
                <p className="text-gray-600 mb-4">{project.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link 
            href="/projects" 
            className="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
          >
            View All Projects
          </Link>
        </div>
      </div>
    </section>
  );
}
