
'use client';

export default function ClientsSection() {
  const clients = [
    { name: 'NHAI', description: 'National Highways Authority of India' },
    { name: 'UPPWD', description: 'Uttar Pradesh Public Works Department' },
    { name: 'IOCL', description: 'Indian Oil Corporation Limited' },
    { name: 'Private Developers', description: 'Various Private Construction Projects' }
  ];

  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Trusted by Leading Organizations
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            We have successfully delivered projects for government agencies and private sector clients
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {clients.map((client, index) => (
            <div key={index} className="bg-gray-800 rounded-lg p-6 text-center hover:bg-gray-700 transition-colors">
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-600 rounded-full flex items-center justify-center">
                <i className="ri-building-line text-2xl text-white w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-semibold mb-2">{client.name}</h3>
              <p className="text-gray-400 text-sm">{client.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
