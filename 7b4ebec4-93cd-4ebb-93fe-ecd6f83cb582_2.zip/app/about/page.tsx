
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AboutHero from './AboutHero';
import CompanyStory from './CompanyStory';
import TeamSection from './TeamSection';
import ClientsSection from './ClientsSection';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <AboutHero />
        <CompanyStory />
        <TeamSection />
        <ClientsSection />
      </main>
      <Footer />
    </div>
  );
}
