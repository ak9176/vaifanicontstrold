
'use client';

export default function AboutHero() {
  return (
    <section 
      className="relative h-96 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Professional%20construction%20team%20meeting%20at%20construction%20site%2C%20engineers%20reviewing%20blueprints%2C%20safety%20helmets%2C%20modern%20office%20building%20in%20background%2C%20corporate%20atmosphere%2C%20professional%20business%20environment&width=1920&height=600&seq=about-hero&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-center w-full">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            About Vaifani Constroworld
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Building trust through quality construction since 2019
          </p>
        </div>
      </div>
    </section>
  );
}
