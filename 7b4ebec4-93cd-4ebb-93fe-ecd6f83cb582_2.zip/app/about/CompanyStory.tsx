
'use client';

export default function CompanyStory() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Our Story Since 2019
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Vaifani Constroworld Pvt. Ltd. was established in 2019 with a vision to deliver 
              exceptional construction services across India. What started as a small team of 
              dedicated civil engineers has grown into a trusted construction company serving 
              both government and private sector clients.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Our commitment to quality, safety, and timely delivery has earned us recognition 
              and certifications including ISO 9001:2015, MSME registration, and Startup India 
              recognition. We take pride in our professional approach and attention to detail 
              in every project we undertake.
            </p>
            <p className="text-lg text-gray-600">
              From highway construction to residential complexes, our diverse portfolio 
              demonstrates our capability to handle projects of varying scales and complexities 
              with equal expertise and dedication.
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-6 text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">50+</div>
              <div className="text-gray-600">Projects Completed</div>
            </div>
            <div className="bg-green-50 rounded-lg p-6 text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">25+</div>
              <div className="text-gray-600">Team Members</div>
            </div>
            <div className="bg-orange-50 rounded-lg p-6 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">5+</div>
              <div className="text-gray-600">Years Experience</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-6 text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">100%</div>
              <div className="text-gray-600">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
