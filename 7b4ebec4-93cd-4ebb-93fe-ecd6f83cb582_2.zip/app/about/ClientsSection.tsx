
'use client';

export default function ClientsSection() {
  const clients = [
    {
      name: 'NHAI',
      fullName: 'National Highways Authority of India',
      description: 'Major highway construction projects including structural work on expressways',
      icon: 'ri-roadster-line'
    },
    {
      name: 'UPPWD',
      fullName: 'Uttar Pradesh Public Works Department',
      description: 'State government infrastructure development projects',
      icon: 'ri-government-line'
    },
    {
      name: 'IOCL',
      fullName: 'Indian Oil Corporation Limited',
      description: 'Industrial facility construction and maintenance projects',
      icon: 'ri-oil-line'
    },
    {
      name: 'Private Developers',
      fullName: 'Various Private Construction Companies',
      description: 'Residential and commercial construction projects',
      icon: 'ri-building-line'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Valued Clients
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We have successfully delivered projects for prestigious government agencies 
            and private sector clients across India.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {clients.map((client, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <i className={`${client.icon} text-blue-600 text-xl w-6 h-6 flex items-center justify-center`}></i>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{client.name}</h3>
                  <p className="text-blue-600 font-medium mb-2">{client.fullName}</p>
                  <p className="text-gray-600">{client.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
