
'use client';

export default function TeamSection() {
  const teamMembers = [
    {
      name: 'Rajesh Kumar',
      position: 'Lead Civil Engineer',
      experience: '12+ years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20civil%20engineer%20in%20hard%20hat%20and%20safety%20vest%20at%20construction%20site%2C%20confident%20male%20engineer%20with%20construction%20background%2C%20professional%20business%20portrait&width=300&height=400&seq=team-member-1&orientation=portrait'
    },
    {
      name: 'Priya Sharma',
      position: 'Project Manager',
      experience: '8+ years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20project%20manager%20in%20construction%20industry%2C%20wearing%20safety%20helmet%2C%20confident%20business%20woman%20with%20construction%20site%20background&width=300&height=400&seq=team-member-2&orientation=portrait'
    },
    {
      name: 'Amit Verma',
      position: 'Site Supervisor',
      experience: '10+ years',
      image: 'https://readdy.ai/api/search-image?query=Experienced%20Indian%20site%20supervisor%20with%20safety%20equipment%2C%20middle-aged%20professional%20man%20at%20construction%20site%2C%20wearing%20hard%20hat%20and%20safety%20vest&width=300&height=400&seq=team-member-3&orientation=portrait'
    },
    {
      name: 'Sunita Gupta',
      position: 'Quality Control Engineer',
      experience: '6+ years',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20quality%20control%20engineer%2C%20wearing%20safety%20gear%2C%20confident%20woman%20with%20construction%20and%20engineering%20background&width=300&height=400&seq=team-member-4&orientation=portrait'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Professional Team
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Meet our team of qualified civil engineers and construction professionals 
            who bring expertise and dedication to every project.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="h-64 bg-cover bg-center" style={{ backgroundImage: `url(${member.image})` }}></div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-blue-600 font-medium mb-1">{member.position}</p>
                <p className="text-gray-600 text-sm">{member.experience}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
