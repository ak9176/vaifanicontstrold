
'use client';

import { useState } from 'react';

export default function ProjectsGallery() {
  const [activeFilter, setActiveFilter] = useState('all');

  const projects = [
    {
      id: 1,
      title: 'Purvanchal Expressway - Structural Work',
      category: 'highway',
      type: 'Highway Infrastructure',
      location: 'Uttar Pradesh',
      status: 'Completed',
      year: '2023',
      description: 'Major structural construction work on the prestigious Purvanchal Expressway project including bridges and flyovers.',
      image: 'https://readdy.ai/api/search-image?query=Purvanchal%20Expressway%20construction%20with%20concrete%20bridge%20structures%2C%20highway%20infrastructure%2C%20modern%20expressway%20development%2C%20professional%20construction%20work&width=600&height=400&seq=purvanchal-detail&orientation=landscape'
    },
    {
      id: 2,
      title: 'Commercial Complex - Dehradun',
      category: 'commercial',
      type: 'Commercial Development',
      location: 'Dehradun, Uttarakhand',
      status: 'In Progress',
      year: '2024',
      description: 'Multi-story commercial building with modern amenities, glass facade, and sustainable design features.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20commercial%20building%20construction%20in%20Dehradun%20with%20glass%20facade%2C%20multi-story%20office%20complex%2C%20contemporary%20architecture%2C%20urban%20development&width=600&height=400&seq=dehradun-detail&orientation=landscape'
    },
    {
      id: 3,
      title: 'Residential Township - Lucknow',
      category: 'residential',
      type: 'Residential Development',
      location: 'Lucknow, Uttar Pradesh',
      status: 'Completed',
      year: '2023',
      description: 'Integrated residential township with 200+ apartments, modern infrastructure, and recreational facilities.',
      image: 'https://readdy.ai/api/search-image?query=Residential%20township%20in%20Lucknow%20with%20multiple%20apartment%20buildings%2C%20modern%20housing%20complex%2C%20landscaped%20environment%2C%20quality%20residential%20development&width=600&height=400&seq=lucknow-detail&orientation=landscape'
    },
    {
      id: 4,
      title: 'Highway Bridge Construction',
      category: 'highway',
      type: 'Bridge Infrastructure',
      location: 'Various Locations',
      status: 'Completed',
      year: '2022',
      description: 'Construction of multiple highway bridges with advanced engineering and safety features.',
      image: 'https://readdy.ai/api/search-image?query=Highway%20bridge%20construction%20with%20concrete%20structures%2C%20bridge%20engineering%2C%20infrastructure%20development%2C%20modern%20bridge%20construction%20techniques&width=600&height=400&seq=bridge-construction&orientation=landscape'
    },
    {
      id: 5,
      title: 'Government Office Building',
      category: 'public',
      type: 'Public Infrastructure',
      location: 'Lucknow, Uttar Pradesh',
      status: 'Completed',
      year: '2022',
      description: 'Modern government office building with sustainable design and efficient space utilization.',
      image: 'https://readdy.ai/api/search-image?query=Government%20office%20building%20construction%20with%20modern%20architecture%2C%20institutional%20building%2C%20professional%20construction%2C%20public%20facility%20development&width=600&height=400&seq=government-building&orientation=landscape'
    },
    {
      id: 6,
      title: 'Luxury Residential Apartments',
      category: 'residential',
      type: 'High-End Residential',
      location: 'Dehradun, Uttarakhand',
      status: 'In Progress',
      year: '2024',
      description: 'Premium residential apartments with modern amenities, landscaped gardens, and luxury finishes.',
      image: 'https://readdy.ai/api/search-image?query=Luxury%20residential%20apartments%20construction%20with%20modern%20design%2C%20high-end%20housing%20development%2C%20premium%20residential%20complex%2C%20contemporary%20architecture&width=600&height=400&seq=luxury-apartments&orientation=landscape'
    }
  ];

  const filters = [
    { key: 'all', label: 'All Projects' },
    { key: 'highway', label: 'Highway & Infrastructure' },
    { key: 'residential', label: 'Residential' },
    { key: 'commercial', label: 'Commercial' },
    { key: 'public', label: 'Public Facilities' }
  ];

  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Construction Projects
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our diverse portfolio of successfully completed and ongoing construction projects
          </p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <button
              key={filter.key}
              onClick={() => setActiveFilter(filter.key)}
              className={`px-6 py-3 rounded-full font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeFilter === filter.key
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div key={project.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="h-64 bg-cover bg-center" style={{ backgroundImage: `url(${project.image})` }}></div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-600">{project.type}</span>
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    project.status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {project.status}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{project.title}</h3>
                <p className="text-gray-600 mb-4">{project.description}</p>
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <i className="ri-map-pin-line w-4 h-4 flex items-center justify-center mr-1"></i>
                  <span>{project.location}</span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <i className="ri-calendar-line w-4 h-4 flex items-center justify-center mr-1"></i>
                  <span>{project.year}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
