
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProjectsHero from './ProjectsHero';
import ProjectsGallery from './ProjectsGallery';
import ProjectStats from './ProjectStats';

export default function ProjectsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ProjectsHero />
        <ProjectsGallery />
        <ProjectStats />
      </main>
      <Footer />
    </div>
  );
}
