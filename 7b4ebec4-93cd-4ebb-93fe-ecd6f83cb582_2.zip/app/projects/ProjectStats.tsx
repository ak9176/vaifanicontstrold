
'use client';

export default function ProjectStats() {
  const stats = [
    {
      number: '50+',
      label: 'Projects Completed',
      icon: 'ri-trophy-line'
    },
    {
      number: '1000+',
      label: 'Kilometers of Roads',
      icon: 'ri-roadster-line'
    },
    {
      number: '25+',
      label: 'Residential Complexes',
      icon: 'ri-home-line'
    },
    {
      number: '100%',
      label: 'On-Time Delivery',
      icon: 'ri-time-line'
    }
  ];

  return (
    <section className="py-20 bg-blue-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Project Statistics
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Numbers that reflect our commitment to excellence and quality delivery
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <i className={`${stat.icon} text-2xl w-8 h-8 flex items-center justify-center`}></i>
              </div>
              <div className="text-4xl font-bold mb-2">{stat.number}</div>
              <div className="text-blue-100">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
