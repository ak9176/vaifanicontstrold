
'use client';

export default function ProjectsHero() {
  return (
    <section 
      className="relative h-96 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Construction%20project%20portfolio%20showcase%20with%20multiple%20construction%20sites%2C%20completed%20buildings%2C%20highway%20construction%2C%20residential%20complexes%2C%20professional%20construction%20achievements&width=1920&height=600&seq=projects-hero&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-center w-full">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our Project Portfolio
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Showcasing our expertise through successfully completed and ongoing construction projects
          </p>
        </div>
      </div>
    </section>
  );
}
