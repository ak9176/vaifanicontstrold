
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section 
      className="relative min-h-screen bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Modern%20construction%20site%20with%20cranes%20and%20buildings%20under%20construction%20against%20blue%20sky%2C%20professional%20corporate%20atmosphere%2C%20clean%20minimal%20background%20with%20construction%20workers%20in%20safety%20gear%2C%20bright%20daylight%20with%20shadows%2C%20architectural%20elements%20visible%2C%20contemporary%20urban%20development%20scene&width=1920&height=1080&seq=hero-bg&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-screen flex items-center">
        <div className="w-full">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              We are Committed to Build your{' '}
              <span className="text-blue-400">Glamorous Dreamworld</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
              Professional construction services since 2019. From highways to residential complexes, 
              we deliver excellence with our team of qualified civil engineers.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                href="/contact" 
                className="bg-blue-600 text-white px-8 py-4 rounded-md hover:bg-blue-700 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer text-center"
              >
                Get Free Quote
              </Link>
              <Link 
                href="/projects" 
                className="border-2 border-white text-white px-8 py-4 rounded-md hover:bg-white hover:text-gray-900 transition-colors font-semibold text-lg whitespace-nowrap cursor-pointer text-center"
              >
                View Projects
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <i className="ri-arrow-down-line text-2xl w-8 h-8 flex items-center justify-center"></i>
      </div>
    </section>
  );
}
