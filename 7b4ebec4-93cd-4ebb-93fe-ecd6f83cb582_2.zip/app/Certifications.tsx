
'use client';

export default function Certifications() {
  const certifications = [
    {
      icon: 'ri-award-line',
      title: 'ISO 9001:2015',
      description: 'Quality Management System Certification',
      color: 'blue'
    },
    {
      icon: 'ri-building-line',
      title: 'MSME Registered',
      description: 'Micro, Small & Medium Enterprise',
      color: 'green'
    },
    {
      icon: 'ri-rocket-line',
      title: 'Startup India',
      description: 'Government of India Recognition',
      color: 'orange'
    }
  ];

  return (
    <section className="py-20 bg-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Certifications
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Recognized for quality and excellence in construction services
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {certifications.map((cert, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-8 text-center hover:shadow-xl transition-shadow">
              <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${
                cert.color === 'blue' ? 'bg-blue-100' : 
                cert.color === 'green' ? 'bg-green-100' : 'bg-orange-100'
              }`}>
                <i className={`${cert.icon} text-2xl ${
                  cert.color === 'blue' ? 'text-blue-600' : 
                  cert.color === 'green' ? 'text-green-600' : 'text-orange-600'
                } w-8 h-8 flex items-center justify-center`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{cert.title}</h3>
              <p className="text-gray-600">{cert.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
