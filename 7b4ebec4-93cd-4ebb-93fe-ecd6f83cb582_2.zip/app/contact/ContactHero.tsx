
'use client';

export default function ContactHero() {
  return (
    <section 
      className="relative h-96 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://readdy.ai/api/search-image?query=Professional%20construction%20office%20environment%20with%20engineers%20at%20work%2C%20modern%20office%20setting%2C%20construction%20consultation%2C%20business%20meeting%20atmosphere&width=1920&height=600&seq=contact-hero&orientation=landscape")'
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-center w-full">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Contact Us
          </h1>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto">
            Get in touch with our team for professional construction services and project consultation
          </p>
        </div>
      </div>
    </section>
  );
}
