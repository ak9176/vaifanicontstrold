
'use client';

export default function ContactInfo() {
  const contactDetails = [
    {
      icon: 'ri-phone-line',
      title: 'Phone',
      info: '9889307968',
      action: 'tel:9889307968'
    },
    {
      icon: 'ri-mail-line',
      title: 'Email',
      info: 'info@vaifaniconstroworld.com',
      action: 'mailto:info@vaifaniconstroworld.com'
    },
    {
      icon: 'ri-map-pin-line',
      title: 'Address',
      info: '503, Cyber heights, Vibhuti Khand, Gomti Nagar, Lucknow - 226010',
      action: null
    },
    {
      icon: 'ri-global-line',
      title: 'Website',
      info: 'www.vaifaniconstroworld.com',
      action: 'http://www.vaifaniconstroworld.com/'
    }
  ];

  const workingHours = [
    { day: 'Monday - Friday', hours: '9:00 AM - 6:00 PM' },
    { day: 'Saturday', hours: '9:00 AM - 4:00 PM' },
    { day: 'Sunday', hours: 'Closed' }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Contact Information
          </h2>
          <p className="text-xl text-gray-600">
            Reach out to us through any of these channels
          </p>
        </div>
        
        <div className="space-y-6 mb-12">
          {contactDetails.map((detail, index) => (
            <div key={index} className="flex items-start bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                <i className={`${detail.icon} text-blue-600 text-xl w-6 h-6 flex items-center justify-center`}></i>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-1">{detail.title}</h3>
                {detail.action ? (
                  <a 
                    href={detail.action}
                    className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer"
                  >
                    {detail.info}
                  </a>
                ) : (
                  <p className="text-gray-600">{detail.info}</p>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">
            Working Hours
          </h3>
          <div className="space-y-3">
            {workingHours.map((schedule, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-gray-600">{schedule.day}</span>
                <span className="font-medium text-gray-900">{schedule.hours}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-8 bg-blue-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Emergency Contact
          </h3>
          <p className="text-gray-600 mb-4">
            For urgent construction matters and emergency services, please call our 24/7 hotline.
          </p>
          <a 
            href="tel:9889307968"
            className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors font-semibold whitespace-nowrap cursor-pointer"
          >
            Call Emergency Line
          </a>
        </div>
      </div>
    </section>
  );
}
