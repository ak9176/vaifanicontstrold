
'use client';

export default function LocationMap() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Location
          </h2>
          <p className="text-xl text-gray-600">
            Visit our office in Lucknow for direct consultation
          </p>
        </div>
        
        <div className="rounded-lg overflow-hidden shadow-lg">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.7890123456789!2d80.9462!3d26.8467!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd991f32b16b%3A0x93ccba8909978be7!2sVibhuti%20Khand%2C%20Gomti%20Nagar%2C%20Lucknow%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1234567890123"
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Vaifani Constroworld Office Location"
          ></iframe>
        </div>
        
        <div className="mt-8 bg-gray-50 p-6 rounded-lg">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">
            How to Reach Us
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <i className="ri-car-line text-2xl text-blue-600 w-8 h-8 flex items-center justify-center mx-auto mb-2"></i>
              <h4 className="font-semibold text-gray-900 mb-2">By Car</h4>
              <p className="text-gray-600 text-sm">
                Free parking available at Cyber Heights building
              </p>
            </div>
            <div className="text-center">
              <i className="ri-bus-line text-2xl text-blue-600 w-8 h-8 flex items-center justify-center mx-auto mb-2"></i>
              <h4 className="font-semibold text-gray-900 mb-2">By Bus</h4>
              <p className="text-gray-600 text-sm">
                Multiple bus routes available to Gomti Nagar
              </p>
            </div>
            <div className="text-center">
              <i className="ri-train-line text-2xl text-blue-600 w-8 h-8 flex items-center justify-center mx-auto mb-2"></i>
              <h4 className="font-semibold text-gray-900 mb-2">By Train</h4>
              <p className="text-gray-600 text-sm">
                15 minutes from Lucknow Junction railway station
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
