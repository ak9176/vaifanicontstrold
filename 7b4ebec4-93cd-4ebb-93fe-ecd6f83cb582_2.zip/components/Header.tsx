
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <img 
                src="https://static.readdy.ai/image/04bec05eb22e0f0dc681e20c942e1cd2/6c3b7b3655fd65f862de22acc1cf31eb.jfif"
                alt="Vaifani Constroworld"
                className="h-10 w-auto"
              />
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium transition-colors whitespace-nowrap">
              Home
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-blue-600 font-medium transition-colors whitespace-nowrap">
              About Us
            </Link>
            <Link href="/services" className="text-gray-700 hover:text-blue-600 font-medium transition-colors whitespace-nowrap">
              Services
            </Link>
            <Link href="/projects" className="text-gray-700 hover:text-blue-600 font-medium transition-colors whitespace-nowrap">
              Projects
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-blue-600 font-medium transition-colors whitespace-nowrap">
              Contact
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <a 
                href="https://wa.me/919889307968" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center w-10 h-10 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors cursor-pointer"
                title="WhatsApp"
              >
                <i className="ri-whatsapp-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <a 
                href="mailto:info@vaifaniconstroworld.com"
                className="flex items-center justify-center w-10 h-10 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors cursor-pointer"
                title="Email"
              >
                <i className="ri-mail-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <div className="text-sm text-gray-600 flex items-center">
                <i className="ri-phone-line w-4 h-4 flex items-center justify-center mr-1"></i>
                <span>9889307968</span>
              </div>
            </div>
            <Link 
              href="/contact" 
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
            >
              Get Quote
            </Link>
          </div>

          <button 
            className="md:hidden p-2 cursor-pointer"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className="ri-menu-line w-6 h-6 flex items-center justify-center"></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-2">
              <Link href="/" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Home
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                About Us
              </Link>
              <Link href="/services" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Services
              </Link>
              <Link href="/projects" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Projects
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600 py-2 cursor-pointer">
                Contact
              </Link>
            </nav>
            <div className="flex items-center space-x-3 mt-4 pt-4 border-t">
              <a 
                href="https://wa.me/919889307968" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center w-10 h-10 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors cursor-pointer"
                title="WhatsApp"
              >
                <i className="ri-whatsapp-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <a 
                href="mailto:info@vaifaniconstroworld.com"
                className="flex items-center justify-center w-10 h-10 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors cursor-pointer"
                title="Email"
              >
                <i className="ri-mail-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <span className="text-sm text-gray-600">9889307968</span>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
