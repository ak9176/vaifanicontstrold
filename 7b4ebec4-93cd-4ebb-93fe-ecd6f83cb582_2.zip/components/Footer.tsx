
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <img 
              src="https://static.readdy.ai/image/04bec05eb22e0f0dc681e20c942e1cd2/6c3b7b3655fd65f862de22acc1cf31eb.jfif"
              alt="Vaifani Constroworld"
              className="h-12 w-auto mb-4"
            />
            <p className="text-gray-400 text-sm">
              Building dreams since 2019 with professional construction services and commitment to excellence.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Home</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors cursor-pointer">About Us</Link></li>
              <li><Link href="/services" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Services</Link></li>
              <li><Link href="/projects" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Projects</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Road Construction</li>
              <li>Real Estate</li>
              <li>Public Facility Construction</li>
              <li>Consultancy</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-2 text-gray-400">
              <div className="flex items-center">
                <i className="ri-phone-line w-4 h-4 flex items-center justify-center mr-2"></i>
                <span>9889307968</span>
              </div>
              <div className="flex items-center">
                <i className="ri-mail-line w-4 h-4 flex items-center justify-center mr-2"></i>
                <span>info@vaifaniconstroworld.com</span>
              </div>
              <div className="flex items-start">
                <i className="ri-map-pin-line w-4 h-4 flex items-center justify-center mr-2 mt-1"></i>
                <span>503, Cyber heights, Vibhuti Khand, Gomti Nagar, Lucknow - 226010</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Vaifani Constroworld Pvt. Ltd. All rights reserved.
            </p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <span className="text-gray-400 text-sm">ISO 9001:2015 Certified</span>
              <span className="text-gray-400 text-sm">MSME Registered</span>
              <span className="text-gray-400 text-sm">Startup India</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
